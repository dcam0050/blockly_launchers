#!/usr/bin/env bash
sleep 10
open index.html
